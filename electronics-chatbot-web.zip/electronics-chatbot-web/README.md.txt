# Electronics Chatbot Web App

This is a web-based electronics chatbot using **Streamlit**.  
It includes:

- Chat-style electronics problem solver  
- Ohm’s Law calculator  
- Series & Parallel resistor calculator  
- Logic gate explanations  
- Circuit diagrams (series/parallel)  
- Logic gate diagrams (AND, OR, NOT)

## Requirements

- Python 3.x  
- streamlit  
- matplotlib

## Installation

1. Clone this repository:

```bash
git clone https://github.com/yourusername/electronics-chatbot-web.git
cd electronics-chatbot-web
